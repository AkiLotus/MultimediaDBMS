import pickle
from sys import argv
from backend_tree import KDTree

# get wavefiles from file with pickle

with open('premade_tree.obj', 'rb') as input:
    tree = pickle.load(input)
    for item in wavefiles: print('{} {}'.format(item.features, item.location))

    tree = KDTree(wavefiles)